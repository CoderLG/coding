package cn.com.geovis.data_import.data_import.model.type;

public enum LayerType {
	
	IMAGELAYER,
	
	VECTORLAYER,
	
	DEMLAYER,
	
	LAYERGROUP,

	TIMELAYER
}
