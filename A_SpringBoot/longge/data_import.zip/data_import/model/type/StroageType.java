package cn.com.geovis.data_import.data_import.model.type;

public enum StroageType {
	
	HBASE, 
	
	IMAGES, 
	
	GV_IMAGE_MBTILE,
	
	GV_TERRAIN_MBTILE,
	
	ARCGISCACHE,

	OGCTWMS_HBASE,

	OGCTWMS_MBTILE,
	
	ROCKS_TILE,

	GV_TIME_ROCKS;
}
